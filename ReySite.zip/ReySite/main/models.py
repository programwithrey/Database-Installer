from django.db import models

# Create your models here.
class Rey(models.Model):
    Rey_Title=models.CharField(max_length=100)
    Rey_content = models.TextField()
    Rey_published = models.DateTimeField("date published")

    def __str__(self):
        return self.Rey_Title
