from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def homepage(request):
    return HttpResponse("<h1>Wow</h1>Nice app<bold>LOL Sus</bold>")
